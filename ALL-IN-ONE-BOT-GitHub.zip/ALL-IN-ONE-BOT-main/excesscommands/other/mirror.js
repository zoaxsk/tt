module.exports = {
    name: 'mirror',
    description: 'Look in the mirror and see something amazing!',
    execute(message) {
        message.reply('🔎 Look in the mirror, and you\'ll see something amazing! **(You!)** 😍');
    },
};
