const path = require('path');

const data = {
    welcomeImages: [
        path.resolve(__dirname, '../welcomeimages/1.png'),
        path.resolve(__dirname, '../welcomeimages/2.jpg'),
        path.resolve(__dirname, '../welcomeimages/3.jpg'),
    ],
};

module.exports = data;
