const cmdIcons = {
    dotIcon: 'https://cdn.discordapp.com/emojis/915658913850998794.gif',
    serverinfoIcon : 'https://cdn.discordapp.com/emojis/942629018296025128.gif',
    YouTubeIcon : 'https://cdn.discordapp.com/emojis/1229455855192379514.png',
    FaceBookIcon : 'https://cdn.discordapp.com/emojis/788969884062711818.png',
    TwitchIcon : 'https://cdn.discordapp.com/emojis/1229455826356404275.gif',
    InstagramIcon : 'https://cdn.discordapp.com/emojis/1188371472104837191.png',
    msgIcon : 'https://cdn.discordapp.com/emojis/915167284648116244.png',
    rippleIcon : 'https://cdn.discordapp.com/emojis/903301195307843595.gif',
    levelUpIcon : 'https://cdn.discordapp.com/emojis/908223980438163476.gif',
    SSRRIcon : 'https://cdn.discordapp.com/emojis/1334648756649590805.png'
};

module.exports = cmdIcons;